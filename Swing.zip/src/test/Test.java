package test;

import controle.AccueilControler;
import vue.Accueil;
import vue.Ajouter;
import vue.Alerte;
import vue.Description;
import vue.Detail;
import vue.Modifier;

public class Test {
    private static AccueilControler accueil;
    
    public static void main(String[] args) {
        accueil = new AccueilControler();
        
    }

}
