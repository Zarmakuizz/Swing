/**
 * Classe de contrôle dans un cadre d'architecture MVC
 */
package controle;

import vue.Detail;
import vue.Modifier;


/**
 * @author namor
 */

public class DetailControler{
    /** La fenêtre */
    protected static Detail vue;
    
}
