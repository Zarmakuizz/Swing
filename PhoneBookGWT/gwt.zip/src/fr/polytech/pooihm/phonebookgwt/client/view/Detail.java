package fr.polytech.pooihm.phonebookgwt.client.view;

public class Detail {

}
